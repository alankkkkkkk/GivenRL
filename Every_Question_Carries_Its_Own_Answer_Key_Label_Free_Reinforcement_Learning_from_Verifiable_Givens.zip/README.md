# GivenRL (ACL format) source

- `paper/`  : compile with `latexmk -pdf main.tex` (official ACL style files, review mode).
- `figure_sources/` : TikZ/pgfplots sources of Figures 1-3 (`pdflatex figX.tex`); `colors.tex` is the shared palette.
- `analysis/paper_numbers.py` : single source of every projected number in the paper.
- `analysis/theory.py` : exact computations behind Fig. 1b, Fig. 3b, psi, gate probabilities (run first; writes theory_values.json).
- `analysis/gen_tables.py` : regenerates `paper/tables/*.tex` from paper_numbers.py.
- `analysis/check_text.py` : cross-checks the numbers quoted in the prose (`python3 check_text.py ../paper/main.tex ../paper/main.tex`).

To replace projections with measured results: edit paper_numbers.py, rerun gen_tables.py and check_text.py, then fix any sentence the checker flags.
