# GivenRL: Label-Free Reasoning through Answer-Conditioned Recovery (ACL format) source

- `paper/`  : compile with `latexmk -pdf main.tex` (official ACL style files, review mode).
- `figure_sources/` : `fig1_teaser.pptx` and `fig2_method.pptx` are native, editable PowerPoint sources of Figures 1 and 2. Each slide is set to the printed size (3.03 in single column; 6.30 in text width), so font sizes on the slide are the printed sizes; export the slide as PDF to `paper/figures/`. `fig3_dynamics.tex` and `fig4_analysis.tex` are TikZ/pgfplots sources of Figures 3 and 4 (`pdflatex figX.tex`); `colors.tex` is the shared palette, which the PowerPoint figures also use.
- `analysis/paper_numbers.py` : single source of every projected number in the paper.
- `analysis/theory.py` : exact computations behind Fig. 3, Fig. 4b, psi, gate probabilities (run first; writes theory_values.json).
- `analysis/gen_tables.py` : regenerates `paper/tables/*.tex` from paper_numbers.py.
- `analysis/check_text.py` : cross-checks the numbers quoted in the prose (`python3 check_text.py ../paper/main.tex ../paper/main.tex`).

To replace projections with measured results: edit paper_numbers.py, rerun gen_tables.py and check_text.py, then fix any sentence the checker flags.
